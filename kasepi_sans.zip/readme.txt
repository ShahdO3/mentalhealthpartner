Free for personal use only

Kasepi Sans Display Typeface is a font that combines a modern style with a classic touch. With bold lines and balanced proportions, this font gives off an attractive and classy impression. Great for use in titles, headers and headline designs that need a strong visual appeal.

This font style is a font that combines strength, clarity, and elegance. With its modern style and classic touch, it is ready to give your design an attractive and classy impression.

Commercial license:
https://creativemarket.com/YUKITACREATIVE/25433221-Kasepi-Sans-Display-Fonts

Buy a coffee:
https://paypal.me/yukitacreative

